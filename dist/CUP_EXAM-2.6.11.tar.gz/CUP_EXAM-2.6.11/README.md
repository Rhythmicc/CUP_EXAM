# China University of Petroleum (Beijing) exam information searcher

## Setup：`pip install CUP_EXAM`
## Run：`$ exam`
